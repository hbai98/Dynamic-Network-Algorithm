Jejuni and Ecoli Netwoks were provided by the author of MI-GRAAL.
(Reference:Kuchaiev, Oleksii, and Nata��sa Pr��zulj1. "Integrative network alignment reveals large regions of global network similarity in yeast and human." Bioinformatics 27.10 (2011): 1390-1396.)

Jejuni network, named "JejuniNet.txt", consists of 1095 nodes and 2988 edges.
Ecoli network, named "EcoliNet.txt", consists of 1935 nodes and 3989 edges.
The file "table.Jejuni-Ecoli.txt" is the homologous table between Jejuni and Ecoli, obtained from C.jejuni-20120524.fasta and EcoliK12-ncbi-20120625.fasta.
The file "MIPS-Jejuni.txt" contains all proteins in JejuniNet.txt,and 'Jejuni-1111' is the network name.