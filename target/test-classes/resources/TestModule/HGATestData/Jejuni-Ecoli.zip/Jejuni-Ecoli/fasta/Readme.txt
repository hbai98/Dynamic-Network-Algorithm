EcoliK12-ncbi-20120625.fasta
Date��2012.6.25
Database��ncbi, uniprot
Method��
       (1)ncbi
          ftp��//ncbi.nlm.nih.gov->genomes->bacteria->ecoli-K12
		  Download fasta files and then get the GI number of the genes.
	   (2)uniprot
	       ID mapping->download->fasta.
Items��4147 items

C.jejuni-20120624.fasta
Date��2012.6.24
Database��sanger Datebase
Method��http://www.sanger.ac.uk/ 
        search for c. jejuni->FTP site->CJ.pep
Items��1731 items