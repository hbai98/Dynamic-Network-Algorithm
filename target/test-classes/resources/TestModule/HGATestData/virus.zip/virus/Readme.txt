These viruses include varicella zoster virus (VZV), Kaposi��s sarcoma-associated herpes virus (KSHV), herpes simplex virus 1 (HSV-1), murine cytomegalovirus (mCMV) and Epstein-Barr virus (EBV).
They are from authors of MI-GRAAL.
(Reference:Kuchaiev, Oleksii, and Nata��sa Pr��zulj1. "Integrative network alignment reveals large regions of global network similarity in yeast and human." Bioinformatics 27.10 (2011): 1390-1396.)

HSV-1,KHSV,mCMV,VZV,EBV network, named "HSVNet.txt,KHSVNet.txt,CMVNet.txt,VZVNet.txt,EBVNet.txt" respectively.
The file "table.HSV-CMV.txt" and other table files are the homologous tables between two species, obtained by the fasta files in fasta directory.
A MIPS file lists all proteins in one network. For example, "MIPS-HSV.txt" contains all proteins in HSVNet.txt, and 'HSV-48' is the network name.
