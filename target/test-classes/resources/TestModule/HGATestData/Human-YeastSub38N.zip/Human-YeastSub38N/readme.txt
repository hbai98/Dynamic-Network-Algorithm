YeastSub38n network, named "net-38n.txt",consists of 38 nodes and 131 edges;
The file "MIPS-Sub38n.txt" contains all proteins in "net-38n.txt",and 'YeastSubNet-38N' is the network name;
Human network named "Human.txt", and the file "table.Yeast-Human.txt" are same with the files in "../data/Human-Yeast".