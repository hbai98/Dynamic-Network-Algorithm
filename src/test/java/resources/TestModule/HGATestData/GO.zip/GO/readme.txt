The two files are downloaded from http://www.uniprot.org/

Download Date:
yeastGO.txt��2012.8.13
humanGO.txt��2012.7.11
